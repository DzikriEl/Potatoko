<?php
    // memanggil koneksi.php untuk melakukan koneksi dengan database
    require "db.php";
    $nama = $_POST['nama'];
    $password = $_POST["password"];

    //melakukan query insert into
    //bagian ini yang berperan memasukkan data yang diinput kedalam database
    $query = mysqli_query($con,"SELECT * FROM `akun` WHERE `nama` = '$nama' and `password` = '$password' ");

    //menampilkan alert untuk menandakan bahwa data sudah berhasil ditambahkan
    $num = mysqli_num_rows($query);
    if ($num == 1) {
        $_SESSION['nama'] = $nama;
        echo "<script>
            alert('Login Success!');
            document.location.href='index.php';
        </script>";
    }else{
        echo "<script>
            alert('Wrong Username or Password!');
            document.location.href='akunlogin.php';
        </script>";
    }
?>