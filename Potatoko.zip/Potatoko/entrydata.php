<?php
    // memanggil koneksi.php untuk melakukan koneksi dengan database
    require "db.php";
    $nama = $_POST['nama'];
    $email = $_POST["email"];
    $password = $_POST["password"];
    //melakukan query insert into
    $query = mysqli_query($con,"SELECT * FROM `akun` WHERE `nama` = '$nama' ");

    //menampilkan alert untuk menandakan bahwa data sudah berhasil ditambahkan
    $num = mysqli_num_rows($query);
    if ($num == 1) {
        echo "<script>
                alert('Username Already taken!');
                document.location.href='akun.php';
            </script>";
    }else{
        $reg = "INSERT INTO akun VALUES ('','$nama','$email','$password')";
        mysqli_query($con, $reg);
        header('location:index.php');
    }
?>