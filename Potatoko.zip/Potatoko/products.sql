-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2020 at 01:06 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id` int(10) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`) VALUES
(1, 'rafel12318', 'rafelinokosgoro123@gmail.com', 'bijikuda'),
(4, 'bonbonbon', 'asfasfasfasfas@gg.com', 'asdasdasd');

-- --------------------------------------------------------

--
-- Table structure for table `beauty_product`
--

CREATE TABLE `beauty_product` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(100) NOT NULL,
  `price` double(9,2) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beauty_product`
--

INSERT INTO `beauty_product` (`id`, `name`, `code`, `price`, `image`) VALUES
(1, 'PIXY Make It Glow Dewy Cushion', 'pixy01', 13.00, 'product-images/1.PNG'),
(2, 'Pixy Aqua Beauty Protect Mist Spray', 'pixy02', 3.00, 'product-images/2.PNG'),
(3, 'Maybelline Fit Me Matte', 'Maybel01', 13.50, 'product-images/3.PNG'),
(4, 'Studio Tropik Original Priming Water', 'sto001', 9.99, 'product-images/4.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(100) NOT NULL,
  `price` double(9,2) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `price`, `image`) VALUES
(1, 'The Division', 'division01', 20.00, 'product-images/divisiongames.jpg'),
(2, 'Fallout 76', 'fallout7601', 30.00, 'product-images/fallout76.jpg'),
(3, 'Metro Exodus', 'metroexodus01', 60.00, 'product-images/metroexodus.jpg'),
(4, 'Red Dead Redemption 2', 'rd201', 70.00, 'product-images/rd2games.jpg'),
(5, 'Skyrim', 'skyrim01', 35.00, 'product-images/skyrimgames.jpg'),
(6, 'The Witcher 3', 'witcher301', 60.00, 'product-images/witcher3.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama` (`nama`);

--
-- Indexes for table `beauty_product`
--
ALTER TABLE `beauty_product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
