<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
<div class="container">
        <a class="navbar-brand font-weight-bold" href="index.php"><span class="font-weight-bold text-white">POTATOKO</span></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active"><a class="nav-link" href="index.php"><span class="font-weight-bold text-white">Beranda</span></a></li>
            </div>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle font-weight-bold text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="gamecategory.php">Game</a>
          <a class="dropdown-item" href="makeup.php">Make Up</a>
        </div>
      </li>
          <form class="form-inline my-2 my-lg-0" method="GET" action="search.php">
                <input class="form-control ml-4" name="search" type= "search" aria-label="Search" >
                <button type="submit" class="btn btn-outline-light ml-2"><span class="font-weight-bold">Search<span></button>
          </form>
            
          <div class="icon">
            <h5>
              &nbsp;
              <a class="far fa-user mr-2 text-white" href="akun.php" data-toggle="tooltip" title="Login"></a>
              <a class="fas fa-envelope mr-2 text-white" href="#" data-toggle="tooltip" title="Pesan Masuk"></a>
              <?php
                if(!empty($_SESSION["shopping_cart"])) {
                $cart_count = count(array_keys($_SESSION["shopping_cart"]));
              ?>
                <div class="cart_div">
                  <a  href="cart.php" class="fas fa-shopping-cart mr-2 text-white" href="#" data-toggle="tooltip" title="Cart"> Cart<span><?php echo $cart_count; ?></span></a>
                </div>
              <?php
                }
              ?>
            </h5>
          </div>
          </ul>
        </div>
    </nav>